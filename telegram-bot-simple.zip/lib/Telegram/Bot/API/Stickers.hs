module Telegram.Bot.API.Stickers where
